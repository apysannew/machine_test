<?php

class Product_model extends CI_Model {

    public function save_product_info($pdata) {
        $this->db->INSERT('products', $pdata);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }

    public function select_all_product() {
        $this->db->select('*');
        $this->db->FROM('products');
        $query_result = $this->db->get();
        $result = $query_result->result();
        return $result;
    }

    public function select_all_images_with_id($this_id) {
        $this->db->select('*');
        $this->db->FROM('images');
        $this->db->WHERE('img_id', $this_id);
        $this->db->limit(3);
        $query_result = $this->db->get();
        $result = $query_result->result();
        return $result;
    }

    public function dele_prod_info($id) {
        $this->db->WHERE('id', $id);
        $this->db->DELETE('products');
        //===============
        $this->db->WHERE('img_id', $id);
        $this->db->DELETE('images');
    }

    public function prod_edit_by_id($id) {
        $this->db->select('*');
        $this->db->FROM('products');
        $this->db->WHERE('id', $id);
        $query_result = $this->db->get();
        $result = $query_result->row();
        return $result;
    }

    public function image_edit_by_id($id) {
        $this->db->select('*');
        $this->db->FROM('images');
        $this->db->WHERE('img_id', $id);
        $query_result = $this->db->get();
        $result = $query_result->result();
        return $result;
    }

    public function update_product_info($id, $pedata) {
        $this->db->WHERE('id', $id);
        $this->db->UPDATE('products', $pedata);
    }

    public function dele_prod_img_info($id) {
        $this->db->WHERE('id', $id);
        $this->db->DELETE('images');
    }

}
