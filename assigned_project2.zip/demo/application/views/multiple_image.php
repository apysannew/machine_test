<!DOCTYPE html>
<html>
    <head>
        <title>Upload Multiple Images in Codeigniter Using Ajax</title>
    </head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
    <script
    src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <style type="text/css">
        .thumb{
            margin: 24px 5px 20px 0;
            float: left;
            width: 75px;
            height: 75px;
        }
        #blah {
            border: 10px solid grey;
            display: block;
            background-color: white;
            border-radius: 15px;
        }
    </style>


    <body>
        <div  class="container">
            <ul class="nav nav-treeview">
                <li class="nav-item">
                    <a href="<?php echo base_url(); ?>Ajax/index" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Add Product</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo base_url(); ?>Ajax/view_product" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>View Products</p>
                    </a>
                </li>
            </ul>
            <div id="divMsg" class="alert alert-success" style="display: none">
                <span id="msg"></span>
            </div>
            <div class="row col-md-8" id="blah">
                <form method="post" id="upload_form" enctype="multipart/form-data"> 
                    <label for="product_name">Product Name</label>
                    <input style="text-transform:uppercase;" required type="text" class="form-control" name="product_name" id="product_name" placeholder="product name">

                    <label for="product_price">Product Price</label>
                    <input required type="text" class="form-control" name="product_price" id="product_price" placeholder="product price">

                    <label for="product_desccription">Description</label>
                    <textarea class="form-control" rows="4" name="product_desccription" id="product_desccription">
                    </textarea>        
                    <div class="form-control col-md-4"></div>                 
            </div>
            <div class="form-control col-md-4"></div>         
            <input type="file" id="image_file" multiple="multiple" />
            <br>
            <div id="uploadPreview"></div>
        </div></br></br><br>
        <div class="form-group col-md-6">
            <br><br>
            <button>Submit</button>
        </div>
    </form>
</div>
</div> 
</body>

<script type="text/javascript">
    $(document).ready(function () {
        $('#upload_form').on('submit', function (e) {
            e.preventDefault();
            if ($('#image_file').val() == '')
            {
                alert("Please Select the File");
            } else
            {
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
                var product_name = $('#product_name').val();
                var product_price = $('#product_price').val();
                var product_desccription = $('#product_desccription').val();
                alert("Product Name :" + product_name + '\n' +
                        "Qty :" + product_price + '\n' +
                        "Description :" + product_desccription + '\n');
                $.ajax({
                    type: "POST",
                    data: {product_name: product_name, product_price: product_price, product_desccription: product_desccription},
                    url: '<?php echo base_url() . "Ajax/detail_insert"; ?>',
                    dataType: "json",
                    success: function (Response_Data) {
                        var last_inserted_id = Response_Data;
                        if (Response_Data > 0)
                        {
//#############################################    
                            var form_data = new FormData();
                            var ins = document.getElementById('image_file').files.length;
                            for (var x = 0; x < ins; x++) {
                                form_data.append("files[]", document.getElementById('image_file').files[x]);
                            }
                            $.ajax({
                                url: "<?php echo base_url(); ?>ajax/multipleImageStore",
                                method: "POST",
                                data: form_data,
                                contentType: false,
                                cache: false,
                                processData: false,
                                dataType: "json",
                                success: function (res)
                                {
                                    console.log(res.success);
                                    if (res.success == true) {
                                        $('#image_file').val('');
                                        $('#uploadPreview').html('');
                                        $('#msg').html(res.msg);
                                        $('#divMsg').show();
                                    } else if (res.success == false) {
                                        $('#msg').html(res.msg);
                                        $('#divMsg').show();
                                    }
                                    setTimeout(function () {
                                        $('#msg').html('');
                                        $('#divMsg').hide();
                                    }, 3000);
                                }
                            });
//#############################################
//999999999999999999999999999999999999999999999
                        }
                    }
                })
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
            }
        });
    });

    function readImage(file) {
        var reader = new FileReader();
        var image = new Image();
        reader.readAsDataURL(file);
        reader.onload = function (_file) {
            image.src = _file.target.result; // url.createObjectURL(file);
            image.onload = function () {
                var w = this.width,
                        h = this.height,
                        t = file.type, // ext only: // file.type.split('/')[1],
                        n = file.name,
                        s = ~~(file.size / 1024) + 'KB';
                $('#uploadPreview').append('<img src="' + this.src + '" class="thumb">');
            };
            image.onerror = function () {
                alert('Invalid file type: ' + file.type);
            };
        };
    }
    $("#image_file").change(function (e) {
        if (this.disabled) {
            return alert('File upload not supported!');
        }
        var F = this.files;
        if (F && F[0]) {
            for (var i = 0; i < F.length; i++) {
                readImage(F[i]);
            }
        }
    });
</script>

</html>